﻿namespace UniSpace.Data.Models.Enums
{
    public enum RoomType
    {
        Computer,
        Seminar
    }
}
