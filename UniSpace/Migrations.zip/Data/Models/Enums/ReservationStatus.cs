﻿namespace UniSpace.Data.Models.Enums
{
    public enum ReservationStatus
    {
        Pending,
        Approved,
        Denied
    }
}
