﻿namespace UniSpace.Data.Models.Enums
{
    public enum CoursesEnum
    {
        I,
        II,
        III,
        IV
    }
}
